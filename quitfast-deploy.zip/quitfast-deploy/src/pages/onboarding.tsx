import { useState } from "react";
import { useLocation } from "wouter";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  const [cigs, setCigs] = useState("20");
  const [price, setPrice] = useState("60");

  if (step === 1) {
    return (
      <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="flex gap-1 mb-10">
            {[1,2,3].map(s => <div key={s} className={`flex-1 h-1 rounded-full ${s <= step ? "bg-[#2563eb]" : "bg-white/10"}`} />)}
          </div>
          <h1 className="text-3xl font-bold mb-2">Hoş geldin! 👋</h1>
          <p className="text-[#bcc8d0] mb-8">Seni daha iyi tanıyalım.</p>
          <label className="text-sm text-[#bcc8d0] mb-2 block">Günde kaç sigara içiyorsun?</label>
          <input type="number" value={cigs} onChange={e => setCigs(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white text-lg outline-none focus:border-[#2563eb] mb-6" />
          <button onClick={() => setStep(2)} className="w-full rounded-xl bg-[#2563eb] py-4 font-bold text-white text-lg">Devam</button>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="flex gap-1 mb-10">
            {[1,2,3].map(s => <div key={s} className={`flex-1 h-1 rounded-full ${s <= step ? "bg-[#2563eb]" : "bg-white/10"}`} />)}
          </div>
          <h1 className="text-3xl font-bold mb-2">Fiyat bilgisi 💰</h1>
          <p className="text-[#bcc8d0] mb-8">Ne kadar tasarruf edeceğini hesaplayalım.</p>
          <label className="text-sm text-[#bcc8d0] mb-2 block">Paket başına fiyat (₺)</label>
          <input type="number" value={price} onChange={e => setPrice(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white text-lg outline-none focus:border-[#2563eb] mb-6" />
          <button onClick={() => setStep(3)} className="w-full rounded-xl bg-[#2563eb] py-4 font-bold text-white text-lg">Devam</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md text-center">
        <div className="flex gap-1 mb-10">
          {[1,2,3].map(s => <div key={s} className="flex-1 h-1 rounded-full bg-[#2563eb]" />)}
        </div>
        <div className="text-7xl mb-6">🚀</div>
        <h1 className="text-3xl font-bold mb-3">Hazırsın!</h1>
        <p className="text-[#bcc8d0] mb-10">Sigarasız yolculuğun başlıyor. Her gün biraz daha güçleniyorsun.</p>
        <button onClick={() => setLocation("/home")} className="w-full rounded-xl bg-[#2563eb] py-4 font-bold text-white text-lg">Başla!</button>
      </div>
    </div>
  );
}

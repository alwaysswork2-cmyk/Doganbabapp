import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { getSupabaseClient } from "../lib/supabase";

type StrengthLevel = "" | "weak" | "medium" | "strong";

function getPasswordStrength(value: string): StrengthLevel {
  if (!value) return "";
  const isStrong =
    value.length >= 10 &&
    /[A-Z]/.test(value) &&
    /[0-9]/.test(value) &&
    /[^a-zA-Z0-9]/.test(value);
  const isMedium = value.length >= 8 && (/[A-Z]/.test(value) || /[0-9]/.test(value));
  if (isStrong) return "strong";
  if (isMedium) return "medium";
  return "weak";
}

export default function Register() {
  const [, setLocation] = useLocation();

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  const strength = getPasswordStrength(password);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (username.trim().length < 3) newErrors.username = "Geçerli bir kullanıcı adı girin.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) newErrors.email = "Geçerli bir e-posta adresi girin.";
    if (!dob) newErrors.dob = "Lütfen doğum tarihinizi girin.";
    if (password.length < 8) newErrors.password = "Şifre en az 8 karakter olmalı.";
    if (!confirm || confirm !== password) newErrors.confirm = "Şifreler eşleşmiyor.";
    return newErrors;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setIsSubmitting(true);
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase.auth.signUp({ email: email.trim(), password });
      if (error) throw error;
      setSuccessMsg("Hesap oluşturuldu! E-postanı doğrulaman gerekebilir.");
    } catch {
      setErrors({ form: "Kayıt tamamlanamadı. Lütfen tekrar dene." });
    } finally {
      setIsSubmitting(false);
    }
  };

  const strengthColors: Record<StrengthLevel, [string, string, string]> = {
    "": ["#1a2f50", "#1a2f50", "#1a2f50"],
    weak: ["#f87171", "#1a2f50", "#1a2f50"],
    medium: ["#fbbf24", "#fbbf24", "#1a2f50"],
    strong: ["#34d399", "#34d399", "#34d399"],
  };
  const bars = strengthColors[strength];

  return (
    <div
      className="relative min-h-dvh"
      style={{
        background: "#050d1a",
        fontFamily: "'DM Sans', sans-serif",
        color: "#f0f6ff",
        WebkitFontSmoothing: "antialiased",
      }}
    >
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(37,99,235,0.22) 0%, transparent 60%)," +
            "radial-gradient(ellipse 40% 30% at 85% 70%, rgba(29,78,216,0.12) 0%, transparent 50%)," +
            "radial-gradient(ellipse 30% 20% at 10% 90%, rgba(59,130,246,0.08) 0%, transparent 50%)",
          zIndex: 0,
        }}
      />

      <div
        className="relative mx-auto flex flex-col items-center px-5 pb-10"
        style={{ zIndex: 1, maxWidth: 430 }}
      >
        <div className="w-full flex items-center justify-center relative pt-5">
          <button
            className="absolute left-0 flex items-center justify-center transition-all"
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              border: "1px solid rgba(59,130,246,0.15)",
              background: "rgba(13,31,60,0.6)",
              backdropFilter: "blur(10px)",
              color: "#60a5fa",
              cursor: "pointer",
            }}
            onClick={() => setLocation("/login")}
            aria-label="Geri"
          >
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
          <span style={{ fontFamily: "'Sora', sans-serif", fontSize: 17, fontWeight: 600, color: "#3b82f6", letterSpacing: "-0.3px" }}>
            QuitFast
          </span>
        </div>

        <div style={{ paddingTop: 6, paddingBottom: 8, width: "100%", display: "flex", flexDirection: "column", gap: 8, animation: "fadeUp 0.5s ease both" }}>
          <button
            type="button"
            className="w-full flex items-center justify-center gap-2.5 transition-all"
            style={{
              height: 40,
              borderRadius: 12,
              background: "#fff",
              border: "none",
              fontSize: 13.5,
              fontWeight: 500,
              color: "#1a1a2e",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            <GoogleIcon />
            Google ile Kayıt Ol
          </button>

          <button
            type="button"
            className="w-full flex items-center justify-center gap-2.5 transition-all"
            style={{
              height: 40,
              borderRadius: 12,
              background: "#1877f2",
              border: "none",
              fontSize: 13.5,
              fontWeight: 500,
              color: "#fff",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.25)",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            <FacebookIcon />
            Facebook ile Kayıt Ol
          </button>
        </div>

        <form className="w-full flex flex-col gap-2" onSubmit={handleSubmit} noValidate>
          <Field label="Kullanıcı Adı" error={errors.username} style={{ animation: "fadeUp 0.5s 0.2s ease both" }}>
            <InputWrap icon={<UserIcon />}>
              <input
                type="text"
                placeholder="kullanici_adi"
                autoComplete="username"
                value={username}
                onChange={(e) => { setUsername(e.target.value); setErrors((prev) => ({ ...prev, username: "" })); }}
                style={inputStyle(!!errors.username)}
              />
            </InputWrap>
          </Field>

          <Field label="E-posta" error={errors.email} style={{ animation: "fadeUp 0.5s 0.25s ease both" }}>
            <InputWrap icon={<MailIcon />}>
              <input
                type="email"
                placeholder="ornek@email.com"
                autoComplete="email"
                value={email}
                onChange={(e) => { setEmail(e.target.value); setErrors((prev) => ({ ...prev, email: "" })); }}
                style={inputStyle(!!errors.email)}
              />
            </InputWrap>
          </Field>

          <Field label="Doğum Tarihi" error={errors.dob} style={{ animation: "fadeUp 0.5s 0.3s ease both" }}>
            <InputWrap icon={<CalendarIcon />}>
              <input
                type="date"
                autoComplete="bday"
                value={dob}
                onChange={(e) => { setDob(e.target.value); setErrors((prev) => ({ ...prev, dob: "" })); }}
                style={{ ...inputStyle(!!errors.dob), colorScheme: "dark" }}
              />
            </InputWrap>
          </Field>

          <Field label="Şifre" error={errors.password} style={{ animation: "fadeUp 0.5s 0.35s ease both" }}>
            <InputWrap icon={<LockIcon />} right={
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                style={{ position: "absolute", right: 13, background: "none", border: "none", cursor: "pointer", color: showPassword ? "#3b82f6" : "#4a6a8f", display: "flex", alignItems: "center", padding: 4 }}
              >
                <EyeIcon />
              </button>
            }>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="En az 8 karakter"
                autoComplete="new-password"
                value={password}
                onChange={(e) => { setPassword(e.target.value); setErrors((prev) => ({ ...prev, password: "" })); }}
                style={inputStyle(!!errors.password)}
              />
            </InputWrap>
          </Field>

          <Field label="Şifre Onay" error={errors.confirm} style={{ animation: "fadeUp 0.5s 0.4s ease both" }}>
            <InputWrap icon={<LockCheckIcon />} right={
              <button
                type="button"
                onClick={() => setShowConfirm((v) => !v)}
                style={{ position: "absolute", right: 13, background: "none", border: "none", cursor: "pointer", color: showConfirm ? "#3b82f6" : "#4a6a8f", display: "flex", alignItems: "center", padding: 4 }}
              >
                <EyeIcon />
              </button>
            }>
              <input
                type={showConfirm ? "text" : "password"}
                placeholder="Şifreni tekrar gir"
                autoComplete="new-password"
                value={confirm}
                onChange={(e) => { setConfirm(e.target.value); setErrors((prev) => ({ ...prev, confirm: "" })); }}
                style={inputStyle(!!errors.confirm)}
              />
            </InputWrap>
          </Field>

          {errors.form && (
            <p style={{ fontSize: 12, color: "#f87171", textAlign: "center" }}>{errors.form}</p>
          )}

          {successMsg ? (
            <button
              type="button"
              style={{
                ...submitBtnStyle,
                background: "linear-gradient(135deg, #059669, #10b981)",
                boxShadow: "0 4px 20px rgba(16,185,129,0.4)",
                animation: "fadeUp 0.5s 0.45s ease both",
              }}
            >
              ✓ {successMsg}
            </button>
          ) : (
            <button
              type="submit"
              disabled={isSubmitting}
              style={{
                ...submitBtnStyle,
                opacity: isSubmitting ? 0.7 : 1,
                animation: "fadeUp 0.5s 0.45s ease both",
              }}
            >
              {isSubmitting ? "İşleniyor..." : "Hesap Oluştur"}
            </button>
          )}
        </form>

        <p style={{ textAlign: "center", fontSize: 13, color: "#8baed4", marginTop: 10, animation: "fadeUp 0.5s 0.5s ease both" }}>
          Zaten hesabın var mı?{" "}
          <button
            type="button"
            onClick={() => setLocation("/login")}
            style={{ color: "#3b82f6", fontWeight: 600, background: "none", border: "none", cursor: "pointer" }}
          >
            Giriş Yap
          </button>
        </p>

        <p style={{ textAlign: "center", fontSize: 11.5, color: "rgba(255,255,255,0.75)", marginTop: 8, lineHeight: 1.6, animation: "fadeUp 0.5s 0.55s ease both" }}>
          Devam ederek{" "}
          <a href="#" style={{ color: "rgba(255,255,255,0.9)", textDecoration: "none" }}>Kullanım Koşulları</a>
          'nı ve{" "}
          <a href="#" style={{ color: "rgba(255,255,255,0.9)", textDecoration: "none" }}>Gizlilik Politikası</a>
          'nı kabul etmiş olursun.
        </p>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(14px); }
          to { opacity: 1; transform: translateY(0); }
        }
        input[type="date"]::-webkit-calendar-picker-indicator {
          opacity: 0;
          position: absolute;
          right: 0;
          width: 100%;
          height: 100%;
          cursor: pointer;
        }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #091224; }
        ::-webkit-scrollbar-thumb { background: #122a52; border-radius: 99px; }
      `}</style>
    </div>
  );
}

function Field({ label, error, children, style }: { label: string; error?: string; children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div className="flex flex-col gap-1.5" style={style}>
      <label style={{ fontSize: 12, fontWeight: 500, color: "#8baed4", letterSpacing: "0.3px", paddingLeft: 2 }}>
        {label}
      </label>
      {children}
      {error && (
        <span style={{ fontSize: 11.5, color: "#f87171", paddingLeft: 4 }}>{error}</span>
      )}
    </div>
  );
}

function InputWrap({ icon, right, children }: { icon: React.ReactNode; right?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="relative flex items-center">
      <span className="absolute left-3.5 flex items-center pointer-events-none" style={{ color: "#4a6a8f" }}>
        {icon}
      </span>
      {children}
      {right}
    </div>
  );
}

function inputStyle(hasError: boolean): React.CSSProperties {
  return {
    width: "100%",
    height: 44,
    background: "rgba(9,18,36,0.7)",
    border: `1px solid ${hasError ? "rgba(248,113,113,0.4)" : "rgba(59,130,246,0.15)"}`,
    borderRadius: 13,
    padding: "0 42px",
    fontFamily: "'DM Sans', sans-serif",
    fontSize: 14,
    color: "#f0f6ff",
    outline: "none",
    backdropFilter: "blur(8px)",
    WebkitAppearance: "none",
  };
}

const submitBtnStyle: React.CSSProperties = {
  width: "100%",
  height: 48,
  borderRadius: 14,
  background: "linear-gradient(135deg, #1a56db 0%, #2563eb 60%, #3b82f6 100%)",
  border: "none",
  fontFamily: "'Sora', sans-serif",
  fontSize: 15,
  fontWeight: 600,
  color: "#fff",
  cursor: "pointer",
  marginTop: 2,
  boxShadow: "0 4px 20px rgba(37,99,235,0.45), 0 0 40px rgba(37,99,235,0.15)",
  letterSpacing: "-0.2px",
};

function UserIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="4" /><path d="M4 20c0-4 3.58-7 8-7s8 3 8 7" /></svg>;
}
function MailIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="M2 7l10 7 10-7" /></svg>;
}
function CalendarIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></svg>;
}
function LockIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>;
}
function LockCheckIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /><path d="M9 16l2 2 4-4" strokeWidth="1.8" /></svg>;
}
function EyeIcon() {
  return <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>;
}
function GoogleIcon() {
  return <svg viewBox="0 0 24 24" width="20" height="20"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" /><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" /><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" /><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" /></svg>;
}
function FacebookIcon() {
  return <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>;
}

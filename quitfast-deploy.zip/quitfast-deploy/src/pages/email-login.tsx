import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { getSupabaseClient } from "../lib/supabase";

export default function EmailLogin() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw error;
      setLocation("/home");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Giriş yapılamadı.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <button onClick={() => setLocation("/login")} className="mb-8 text-[#60a5fa]">← Geri</button>
        <h1 className="text-2xl font-bold mb-8">E-posta ile Giriş</h1>
        <div className="space-y-4">
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="E-posta"
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Şifre"
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
          {error && <p className="text-red-400 text-sm">{error}</p>}
          <button onClick={handleSubmit as any} disabled={loading}
            className="w-full rounded-xl bg-[#2563eb] py-3 font-bold text-white disabled:opacity-60">
            {loading ? "Giriş yapılıyor..." : "Giriş Yap"}
          </button>
        </div>
      </div>
    </div>
  );
}

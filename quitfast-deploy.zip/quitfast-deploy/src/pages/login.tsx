import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { getSupabaseClient } from "../lib/supabase";
import quitFastLogoIcon from "../assets/quitfast-logo-icon.png";

type AuthMode = "login" | "register";

export default function Login() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<AuthMode>("login");
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const [statusType, setStatusType] = useState<"idle" | "success" | "error">("idle");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isRegister = mode === "register";
  const actionLabel = isRegister ? "Kayıt Ol" : "Giriş Yap";

  const resetFormState = () => {
    setStatusMessage("");
    setStatusType("idle");
    setEmail("");
    setPassword("");
  };

  const switchMode = (nextMode: AuthMode) => {
    setMode(nextMode);
    setShowEmailForm(true);
    resetFormState();
  };

  const handleEmailAuth = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatusMessage("");
    setStatusType("idle");

    if (!email.trim() || !password.trim()) {
      setStatusType("error");
      setStatusMessage("Lütfen e-posta ve şifreni gir.");
      return;
    }

    if (password.length < 6) {
      setStatusType("error");
      setStatusMessage("Şifre en az 6 karakter olmalı.");
      return;
    }

    setIsSubmitting(true);

    try {
      const supabase = getSupabaseClient();
      const { error } = isRegister
        ? await supabase.auth.signUp({ email: email.trim(), password })
        : await supabase.auth.signInWithPassword({ email: email.trim(), password });

      if (error) throw error;

      setStatusType("success");
      setStatusMessage(isRegister ? "Kayıt başarılı. E-postanı doğrulaman gerekebilir." : "Giriş başarılı.");
    } catch (error) {
      setStatusType("error");
      setStatusMessage(error instanceof Error ? error.message : "İşlem tamamlanamadı.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] selection:bg-[#2563eb] selection:text-white" style={{ fontFamily: "'Manrope', sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;800&family=Sora:wght@600&display=swap" rel="stylesheet" />

      {/* Header — back button only, no QuitFast text */}
      <header className="fixed top-0 w-full z-50 flex items-center px-6 py-4 bg-gradient-to-b from-[#061020] to-transparent">
        <button
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#2563eb]/20 transition-colors active:scale-90 duration-150 text-[#60a5fa]"
          onClick={() => setLocation("/habits")}
          data-testid="button-back-habits"
        >
          <ArrowLeft />
        </button>
      </header>

      <main className="min-h-screen pt-16 pb-10 px-6 flex flex-col items-center justify-center max-w-md mx-auto relative">

        {/* Logo + QuitFast — Playfair style matching welcome page, slightly higher */}
        <div className="flex flex-col items-center mb-5 mt-[-12px]">
          <img src={quitFastLogoIcon} alt="QuitFast" className="h-16 w-16 object-contain rounded-2xl mb-2" />
          <span
            style={{
              fontFamily: "'Sora', sans-serif",
              fontStyle: "normal",
              fontWeight: 600,
              fontSize: 17,
              color: "#3b82f6",
              letterSpacing: "-0.3px",
            }}
          >
            QuitFast
          </span>
        </div>

        {/* Title only — no subtitle */}
        <div className="text-center mb-7">
          <h1 className="text-[28px] leading-tight font-bold tracking-[-0.2px] text-white" data-testid="text-login-title">
            Hesabına {actionLabel}
          </h1>
        </div>

        {/* Login option buttons — white border, slightly smaller */}
        <div className="w-full space-y-3">
          <button
            className="w-full flex items-center justify-center gap-3 py-3 px-5 bg-transparent border border-white/80 text-white rounded-xl font-bold transition-transform hover:scale-[1.02] active:scale-[0.98]"
            data-testid="button-google-login"
          >
            <GoogleIcon />
            <span>Google ile {actionLabel}</span>
          </button>

          <button
            className="w-full flex items-center justify-center gap-3 py-3 px-5 bg-transparent border border-white/80 text-white rounded-xl font-bold transition-transform hover:scale-[1.02] active:scale-[0.98]"
            data-testid="button-facebook-login"
          >
            <FacebookIcon />
            <span>Facebook ile {actionLabel}</span>
          </button>

          <button
            className="w-full flex items-center justify-center gap-3 py-3 px-5 bg-transparent border border-white/80 text-white rounded-xl font-bold transition-transform hover:scale-[1.02] active:scale-[0.98]"
            onClick={() => {
              setShowEmailForm((current) => !current);
              setStatusMessage("");
              setStatusType("idle");
            }}
            data-testid="button-email-login"
          >
            <MailIcon />
            <span>E-posta ile {actionLabel}</span>
          </button>

          {showEmailForm && (
            <form className="rounded-2xl border border-[#2563eb]/50 bg-[#08162b] p-4 space-y-3" onSubmit={handleEmailAuth} data-testid="form-email-login">
              <input
                className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none placeholder:text-[#bcc8d0]/45 focus:border-[#2563eb]"
                type="email"
                inputMode="email"
                autoComplete="email"
                placeholder="E-posta adresin"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                data-testid="input-email"
              />
              <input
                className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none placeholder:text-[#bcc8d0]/45 focus:border-[#2563eb]"
                type="password"
                autoComplete={isRegister ? "new-password" : "current-password"}
                placeholder="Şifren"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                data-testid="input-password"
              />
              <button
                className="w-full rounded-xl bg-[#2563eb] px-4 py-3 font-bold text-white transition-transform active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-60"
                type="submit"
                disabled={isSubmitting}
                data-testid="button-submit-email-login"
              >
                {isSubmitting ? "İşleniyor..." : actionLabel}
              </button>
              {statusMessage && (
                <p
                  className={`text-center text-xs leading-relaxed ${statusType === "success" ? "text-[#60a5fa]" : "text-[#ff8a8a]"}`}
                  data-testid="text-email-login-status"
                >
                  {statusMessage}
                </p>
              )}
            </form>
          )}
        </div>

        <div className="w-full flex items-center my-6">
          <div className="flex-grow h-px bg-[#3c494f]/20" />
          <span className="px-4 text-xs uppercase tracking-widest text-[#bcc8d0]/60 font-bold">veya</span>
          <div className="flex-grow h-px bg-[#3c494f]/20" />
        </div>

        <div className="flex flex-col items-center gap-5">
          <p className="text-sm text-[#bcc8d0]">
            {isRegister ? "Zaten hesabın var mı?" : "Hesabın yok mu?"}
            <button
              className="text-[#60a5fa] font-bold ml-1 hover:underline decoration-[#2563eb] underline-offset-4"
              onClick={() => isRegister ? switchMode("login") : setLocation("/register")}
              data-testid="button-register-link"
            >
              {isRegister ? "Giriş Yap" : "Kayıt Ol"}
            </button>
          </p>
          {!isRegister && (
            <button className="text-xs text-[#bcc8d0]/40 hover:text-[#d7e3fc] transition-colors" data-testid="button-forgot-password">
              Şifremi Unuttum
            </button>
          )}
        </div>

        <div className="fixed -bottom-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#2563eb]/10 blur-[120px] rounded-full pointer-events-none" />
      </main>
    </div>
  );
}

function ArrowLeft() {
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></svg>;
}

function GoogleIcon() {
  return <svg className="w-5 h-5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" /><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" /><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" /><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" /></svg>;
}

function FacebookIcon() {
  return <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" /></svg>;
}

function MailIcon() {
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" /></svg>;
}

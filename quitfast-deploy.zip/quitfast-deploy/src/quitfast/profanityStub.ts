import { PROFANITY_LIST } from "./profanityList";
export function checkProfanity(text: string): boolean {
  return PROFANITY_LIST.some((word) => text.toLowerCase().includes(word));
}

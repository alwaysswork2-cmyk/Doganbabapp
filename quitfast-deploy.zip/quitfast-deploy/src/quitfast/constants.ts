import { ProgramDay } from "./types";

export const PROGRAM_DAYS: ProgramDay[] = Array.from({ length: 90 }, (_, i) => ({
  day: i + 1,
  title: `Gün ${i + 1}`,
  description: i === 0
    ? "Sigara içmeden geçirdiğin her gün, bedenin ve zihnin için büyük bir zafer."
    : `${i + 1}. gününde de devam et. Kararlılığın seni ileriye taşıyor.`,
  tasks: [
    "Nefes egzersizi yap (5 dakika)",
    "Su iç, hareket et",
    "Bugün sigarasız kaldın mı? İşaretle!",
  ],
  tip: i % 7 === 0 ? "Bir hafta daha tamamladın! Kendini ödüllendir." : undefined,
}));

export const NICOTINE_GOALS = [
  { id: "n1", title: "İlk 24 Saat", description: "24 saat sigarasız kal", xp: 50, days: 1 },
  { id: "n2", title: "3 Gün", description: "3 gün sigarasız kal", xp: 100, days: 3 },
  { id: "n3", title: "1 Hafta", description: "7 gün sigarasız kal", xp: 200, days: 7 },
  { id: "n4", title: "2 Hafta", description: "14 gün sigarasız kal", xp: 350, days: 14 },
  { id: "n5", title: "1 Ay", description: "30 gün sigarasız kal", xp: 600, days: 30 },
  { id: "n6", title: "3 Ay", description: "90 gün sigarasız kal", xp: 1200, days: 90 },
];

export const HEALTH_GOALS = [
  { id: "h1", title: "Kan Basıncı Normale Döner", description: "20 dakika sonra", xp: 30, minutes: 20 },
  { id: "h2", title: "Karbonmonoksit Temizlenir", description: "12 saat sonra", xp: 50, minutes: 720 },
  { id: "h3", title: "Dolaşım İyileşir", description: "2-12 hafta sonra", xp: 100, minutes: 20160 },
  { id: "h4", title: "Akciğer Kapasitesi Artar", description: "1-9 ay sonra", xp: 200, minutes: 43200 },
  { id: "h5", title: "Kalp Krizi Riski Azalır", description: "1 yıl sonra", xp: 500, minutes: 525600 },
];

export const SAVINGS_GOALS = [
  { id: "s1", title: "İlk 100₺", description: "100₺ biriktir", xp: 50, amount: 100 },
  { id: "s2", title: "500₺ Birikti", description: "500₺ biriktir", xp: 150, amount: 500 },
  { id: "s3", title: "1.000₺ Birikti", description: "1.000₺ biriktir", xp: 300, amount: 1000 },
  { id: "s4", title: "5.000₺ Birikti", description: "5.000₺ biriktir", xp: 800, amount: 5000 },
];

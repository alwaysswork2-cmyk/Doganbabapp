export interface Badge {
  id: string;
  title: string;
  description: string;
  emoji: string;
  requiredDays?: number;
  requiredXp?: number;
}

export const BADGES_DATA: Badge[] = [
  { id: "b1", title: "İlk Adım", description: "İlk sigarasız gün", emoji: "🌱", requiredDays: 1 },
  { id: "b2", title: "3 Gün Savaşçısı", description: "3 gün sigarasız", emoji: "⚔️", requiredDays: 3 },
  { id: "b3", title: "Haftalık Kahraman", description: "7 gün sigarasız", emoji: "🦸", requiredDays: 7 },
  { id: "b4", title: "İki Hafta Ustası", description: "14 gün sigarasız", emoji: "🏆", requiredDays: 14 },
  { id: "b5", title: "Aylık Şampiyon", description: "30 gün sigarasız", emoji: "👑", requiredDays: 30 },
  { id: "b6", title: "XP Toplayıcı", description: "500 XP kazandı", emoji: "⚡", requiredXp: 500 },
  { id: "b7", title: "XP Ustası", description: "2000 XP kazandı", emoji: "💎", requiredXp: 2000 },
  { id: "b8", title: "3 Aylık Efsane", description: "90 gün sigarasız", emoji: "🌟", requiredDays: 90 },
];

export function BadgeIcon({ emoji, size = 32 }: { emoji: string; size?: number }) {
  return (
    <span style={{ fontSize: size }} role="img" aria-label="badge">
      {emoji}
    </span>
  );
}

import { Step, OnboardingData } from "../types";

interface Props {
  onNavigate: (step: Step) => void;
  onboardingData: OnboardingData;
  onUpdateOnboarding: (data: OnboardingData) => void;
}

export default function HabitEditPage({ onNavigate, onboardingData, onUpdateOnboarding }: Props) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <h1 className="text-2xl font-bold mb-4">Alışkanlık Düzenle</h1>
      <div className="w-full max-w-md space-y-4">
        <div>
          <label className="text-sm text-[#bcc8d0] mb-1 block">Günlük Sigara Sayısı</label>
          <input
            type="number"
            value={onboardingData.dailyCigarettes}
            onChange={(e) => onUpdateOnboarding({ ...onboardingData, dailyCigarettes: Number(e.target.value) })}
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]"
          />
        </div>
        <div>
          <label className="text-sm text-[#bcc8d0] mb-1 block">Paket Başına Fiyat (₺)</label>
          <input
            type="number"
            value={onboardingData.pricePerPack}
            onChange={(e) => onUpdateOnboarding({ ...onboardingData, pricePerPack: Number(e.target.value) })}
            className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]"
          />
        </div>
        <button
          onClick={() => onNavigate("settings")}
          className="w-full rounded-xl bg-[#2563eb] px-4 py-3 font-bold text-white"
        >
          Kaydet
        </button>
      </div>
    </div>
  );
}

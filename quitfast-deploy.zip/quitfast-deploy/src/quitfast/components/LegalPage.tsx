import { Step } from "../types";

interface Props { onNavigate: (step: Step) => void; }

export default function LegalPage({ onNavigate }: Props) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("settings")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-4">Gizlilik & Yasal</h1>
      <p className="text-[#bcc8d0] text-sm leading-relaxed">
        QuitFast uygulaması kişisel verilerinizi yalnızca hesap yönetimi ve uygulama işlevselliği için kullanır.
        Verileriniz üçüncü taraflarla paylaşılmaz.
      </p>
    </div>
  );
}

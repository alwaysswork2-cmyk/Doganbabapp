import { useState } from "react";
import { Step, Reward } from "../types";

interface CharacterSelectionProps {
  onNavigate: (step: Step) => void;
  currentAvatar: string;
  onSelect: (avatar: string) => void;
}

const CHARACTERS = [
  { id: "c1", name: "Kahraman", url: "https://api.dicebear.com/7.x/avataaars/svg?seed=Hero&backgroundColor=b6e3f4&radius=50" },
  { id: "c2", name: "Savaşçı", url: "https://api.dicebear.com/7.x/avataaars/svg?seed=Warrior&backgroundColor=ffd5dc&radius=50" },
  { id: "c3", name: "Bilge", url: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sage&backgroundColor=c0aede&radius=50" },
  { id: "c4", name: "Dedektif", url: "https://api.dicebear.com/7.x/avataaars/svg?seed=Detective&backgroundColor=d1d4f9&radius=50" },
];

export function CharacterSelectionPage({ onNavigate, currentAvatar, onSelect }: CharacterSelectionProps) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("profile")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-6">Karakter Seç</h1>
      <div className="grid grid-cols-2 gap-4">
        {CHARACTERS.map((c) => (
          <button
            key={c.id}
            onClick={() => { onSelect(c.url); onNavigate("profile"); }}
            className={`rounded-2xl p-4 border-2 flex flex-col items-center gap-2 transition-all ${currentAvatar === c.url ? "border-[#2563eb] bg-[#0d1f3c]" : "border-white/10 bg-[#08162b]"}`}
          >
            <img src={c.url} alt={c.name} className="w-20 h-20 rounded-xl" />
            <span className="text-sm font-medium">{c.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

interface RewardsPageProps {
  onNavigate: (step: Step) => void;
  rewards: Reward[];
  moodHistory: { day: number; emoji: string }[];
  currentDay: number;
}

export function RewardsPage({ onNavigate, rewards, moodHistory, currentDay }: RewardsPageProps) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("profile")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Ödüllerim</h1>
        <button onClick={() => onNavigate("add_reward")} className="text-sm text-[#60a5fa] font-medium">+ Ekle</button>
      </div>
      {rewards.length === 0 ? (
        <div className="flex flex-col items-center justify-center mt-20 gap-4">
          <span className="text-5xl">🎁</span>
          <p className="text-[#bcc8d0] text-center">Henüz ödül eklemedin.<br />Kendine bir hedef koy!</p>
          <button onClick={() => onNavigate("add_reward")} className="rounded-xl bg-[#2563eb] px-6 py-3 font-bold text-white">İlk Ödülünü Ekle</button>
        </div>
      ) : (
        <div className="space-y-3">
          {rewards.map((r) => (
            <div key={r.id} className="bg-[#0d1f3c] rounded-2xl p-4 flex items-center gap-4">
              <span className="text-3xl">{r.emoji}</span>
              <div className="flex-1">
                <div className="font-semibold">{r.title}</div>
                <div className="text-xs text-[#bcc8d0]">{r.currentAmount}₺ / {r.targetAmount}₺</div>
                <div className="mt-1 h-1.5 bg-white/10 rounded-full">
                  <div className="h-full bg-[#2563eb] rounded-full" style={{ width: `${Math.min(100, (r.currentAmount / r.targetAmount) * 100)}%` }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

interface AddRewardPageProps {
  onNavigate: (step: Step) => void;
  onAdd: (reward: Omit<Reward, "id" | "currentAmount">) => void;
}

export function AddRewardPage({ onNavigate, onAdd }: AddRewardPageProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [emoji, setEmoji] = useState("🎁");

  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("rewards")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-6">Ödül Ekle</h1>
      <div className="space-y-4">
        <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ödül adı" className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
        <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Açıklama" className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
        <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Hedef tutar (₺)" className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
        <input value={emoji} onChange={e => setEmoji(e.target.value)} placeholder="Emoji" className="w-full rounded-xl border border-white/10 bg-[#050d1a] px-4 py-3 text-white outline-none focus:border-[#2563eb]" />
        <button
          onClick={() => { if (title && amount) { onAdd({ title, description, targetAmount: Number(amount), emoji }); onNavigate("rewards"); } }}
          className="w-full rounded-xl bg-[#2563eb] px-4 py-3 font-bold text-white"
        >Kaydet</button>
      </div>
    </div>
  );
}

interface EditRewardsPageProps {
  onNavigate: (step: Step) => void;
  rewards: Reward[];
  onDelete: (id: string) => void;
}

export function EditRewardsPage({ onNavigate, rewards, onDelete }: EditRewardsPageProps) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("rewards")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-6">Ödülleri Düzenle</h1>
      <div className="space-y-3">
        {rewards.map((r) => (
          <div key={r.id} className="bg-[#0d1f3c] rounded-2xl p-4 flex items-center gap-4">
            <span className="text-3xl">{r.emoji}</span>
            <div className="flex-1">
              <div className="font-semibold">{r.title}</div>
              <div className="text-xs text-[#bcc8d0]">{r.targetAmount}₺</div>
            </div>
            <button onClick={() => onDelete(r.id)} className="text-red-400 text-sm font-medium">Sil</button>
          </div>
        ))}
      </div>
    </div>
  );
}

import { Step } from "../types";

interface MoodSelectionProps {
  onNavigate: (step: Step) => void;
  onMoodSelect: (mood: { emoji: string; label: string }) => void;
}

const MOODS = [
  { emoji: "😄", label: "Harika" },
  { emoji: "🙂", label: "İyi" },
  { emoji: "😐", label: "Orta" },
  { emoji: "😔", label: "Kötü" },
  { emoji: "😤", label: "Sinirli" },
  { emoji: "😰", label: "Endişeli" },
];

export function MoodSelection({ onNavigate, onMoodSelect }: MoodSelectionProps) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <button onClick={() => onNavigate("dashboard")} className="mb-6 self-start text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-2">Bugün nasılsın?</h1>
      <p className="text-[#bcc8d0] mb-8 text-center text-sm">Ruh halini seç</p>
      <div className="grid grid-cols-3 gap-4 w-full max-w-xs">
        {MOODS.map((m) => (
          <button
            key={m.emoji}
            onClick={() => { onMoodSelect(m); onNavigate("dashboard"); }}
            className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-[#0d1f3c] hover:bg-[#1a3a6b] transition-colors active:scale-95"
          >
            <span className="text-4xl">{m.emoji}</span>
            <span className="text-xs text-[#bcc8d0]">{m.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

interface MoodReportProps {
  onNavigate: (step: Step) => void;
  moodHistory: { day: number; emoji: string; entry?: string }[];
  currentDay: number;
}

export function MoodReportPage({ onNavigate, moodHistory, currentDay }: MoodReportProps) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("profile")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-6">Ruh Hali Raporu</h1>
      {moodHistory.length === 0 ? (
        <p className="text-[#bcc8d0] text-center mt-12">Henüz ruh hali kaydı yok.</p>
      ) : (
        <div className="space-y-3">
          {[...moodHistory].reverse().map((h, i) => (
            <div key={i} className="flex items-center gap-4 bg-[#0d1f3c] rounded-2xl p-4">
              <span className="text-3xl">{h.emoji}</span>
              <span className="text-[#bcc8d0] text-sm">Gün {h.day}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { Step } from "../types";

interface Props { onNavigate: (step: Step) => void; }

export default function AudioPlayerPrototype({ onNavigate }: Props) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <button onClick={() => onNavigate("dashboard")} className="mb-6 self-start text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-4">Sesli İçerik</h1>
      <p className="text-[#bcc8d0]">Sesli blog içerikleri blog sayfasından erişilebilir.</p>
    </div>
  );
}

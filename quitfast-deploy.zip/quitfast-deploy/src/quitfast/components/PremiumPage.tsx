import { Step } from "../types";

interface Props {
  onNavigate: (step: Step) => void;
  setIsPremium: (v: boolean) => void;
  returnStep: Step;
}

export default function PremiumPage({ onNavigate, setIsPremium, returnStep }: Props) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] flex flex-col items-center justify-center p-6">
      <button onClick={() => onNavigate(returnStep)} className="mb-6 self-start text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-2">QuitFast Premium</h1>
      <p className="text-[#bcc8d0] mb-8 text-center">Tüm özelliklerin kilidini aç</p>
      <button
        onClick={() => { setIsPremium(true); onNavigate(returnStep); }}
        className="w-full max-w-xs rounded-xl bg-gradient-to-r from-yellow-500 to-orange-500 px-4 py-4 font-bold text-white text-lg"
      >
        Premium'a Geç
      </button>
    </div>
  );
}

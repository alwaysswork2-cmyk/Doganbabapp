import { Step } from "../types";

interface Props {
  onNavigate: (step: Step) => void;
  currentAvatar: string;
  onSelect: (avatar: string) => void;
}

const AVATARS = [
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Felix&backgroundColor=b6e3f4&radius=50",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Mia&backgroundColor=c0aede&radius=50",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Zara&backgroundColor=d1d4f9&radius=50",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Leo&backgroundColor=b6e3f4&radius=50",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Kai&backgroundColor=ffd5dc&radius=50",
  "https://api.dicebear.com/7.x/avataaars/svg?seed=Nova&backgroundColor=c0aede&radius=50",
];

export function AvatarCustomizer({ onNavigate, currentAvatar, onSelect }: Props) {
  return (
    <div className="min-h-dvh bg-[#061020] text-[#d7e3fc] p-6">
      <button onClick={() => onNavigate("profile")} className="mb-6 text-[#60a5fa]">← Geri</button>
      <h1 className="text-2xl font-bold mb-6">Avatar Seç</h1>
      <div className="grid grid-cols-3 gap-4">
        {AVATARS.map((url) => (
          <button
            key={url}
            onClick={() => { onSelect(url); onNavigate("profile"); }}
            className={`rounded-2xl p-2 border-2 transition-all ${currentAvatar === url ? "border-[#2563eb]" : "border-transparent"}`}
          >
            <img src={url} alt="avatar" className="w-full rounded-xl" />
          </button>
        ))}
      </div>
    </div>
  );
}

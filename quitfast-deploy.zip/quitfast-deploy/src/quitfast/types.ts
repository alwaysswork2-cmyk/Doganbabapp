export type Step =
  | "dashboard"
  | "blogs"
  | "profile"
  | "program"
  | "crisis"
  | "puzzle"
  | "ranking"
  | "badges"
  | "settings"
  | "habit_edit"
  | "account_info"
  | "notifications"
  | "legal"
  | "premium"
  | "audio_prototype"
  | "goals"
  | "health_goals"
  | "mood_selection"
  | "mood_report"
  | "character_selection"
  | "avatar_customizer"
  | "rewards"
  | "add_reward"
  | "edit_rewards";

export interface OnboardingData {
  age: number;
  dailyCigarettes: number;
  packsPerDay: number;
  cigarettesPerPack: number;
  pricePerPack: number;
}

export interface Reward {
  id: string;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  emoji: string;
}

export interface NotificationSettings {
  dailyMotivation: boolean;
  crisisMoment: boolean;
  weeklyReport: boolean;
  savingsUpdate: boolean;
  milestoneAlert: boolean;
}

export interface ProgramDay {
  day: number;
  title: string;
  description: string;
  tasks: string[];
  tip?: string;
}

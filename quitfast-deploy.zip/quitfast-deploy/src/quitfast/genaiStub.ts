export enum Modality {
  AUDIO = "AUDIO",
  TEXT = "TEXT",
}

export class GoogleGenAI {
  private apiKey: string;
  constructor({ apiKey }: { apiKey: string }) {
    this.apiKey = apiKey;
  }
  models = {
    generateContent: async (params: any) => {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${params.model}:generateContent?key=${this.apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: params.contents, generationConfig: params.generationConfig }),
        }
      );
      return res.json();
    },
  };
}
